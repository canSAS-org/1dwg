#include <stdio.h>
#include <string.h>
#include "xmlParser.h"
#define MAXNODES 10000
XMLNode pfound[MAXNODES];
/* all attempts to use pointers for XMLNode array fail
with segment violation. Note operator= overload in XMLNode...
intercepts all copies! */
XMLCSTR pname [MAXNODES];
int lpname [MAXNODES];
XMLNode thisnod;
XMLNode curnod;
int curset = 0;
int numnod = 0;
int numnth = 0;
int nnsnod =0;
int nnatt = 0;
int nntext = 0;
int limfound = MAXNODES;
int nfound;

extern "C" { int rxmlopen_ ( char *fname, int flen) 
/* Fortran input name trimmed - no trailing blanks...
   this order of arguments satisfies MSVC and gcc */
/* Get all NODE names*/
{
void findnams(XMLCSTR);
char ffname [100];
int ii;
int llen;
char *cpname;
llen = flen;
cpname= fname;
/* note from fortran the strings are NOT zero terminated...*/
/* it is necessary to reconstruct the CSTR*/
for ( ii=0; ii < llen ; ii++ ) ffname[ii]=*cpname++;
ffname[ii]=0;
XMLCSTR file = ffname;
XMLResults *pres = NULL;
XMLCSTR tag = NULL;
XMLNode root =XMLNode::parseFile(file, tag, pres);
/*printf( " pres %s  name %s\n",pres,root.getName());  > NULL xml */
thisnod = root;
XMLCSTR nam = "+";
/* should never match!*/
findnams(nam);
return nfound;
}
void findnams(XMLCSTR find)
/* initialise search - find all nodenames*/
/* start from current path*/
{
void downtest(XMLCSTR, XMLNode);
XMLNode fnod;
fnod = thisnod;
XMLCSTR tofind = find;
nfound=0;
downtest(tofind, fnod);
return;
}
void downtest(XMLCSTR find, XMLNode from)
{
XMLCSTR nextnam;
int nsrch = 0;
int i = 0;
/*printf("in downtest tofind %s ",find);*/
XMLCSTR tofind = find;
XMLNode ffrom = from;
nsrch = ffrom.nChildNode();
/*printf(" nsrch %d \n",nsrch);*/
while (i < nsrch ){ 
XMLNode next = ffrom.getChildNode(i);
nextnam=next.getName();
i++;
/*printf("i %d curnam  %s\n",i, nextnam);*/
/* store name and location - sort later */
pfound[nfound]=next;
pname[nfound]=nextnam;
lpname[nfound++] = strlen(nextnam);
downtest (find, next);
}
} 


int mgetf_ (float *f, int *limf, char *nname, int lnname)
{
char nodnam[60];
char *nnod;
XMLNode ppfound;
XMLCSTR ppname;
int kk;
int jj=0;
float *ff;
float gg;
int *limit;
int llimit;
int nval =0;
int ntxt;
int llnname;
int ierrf = 0;
nnod=nname;
limit=limf;
llimit=*limf;
/* fortran table limit */
llnname=lnname;
ff=f;
/* name of node sought */
for ( kk=0 ; kk < lnname ; kk++ ) nodnam[kk]= *nnod++ ;
nodnam[lnname] = 0;
nnod=nodnam;
for (kk=0 ; kk< nfound; kk++) {
  /*search list for matching name could optimise by several sort sorts */
  ppname = pname[kk];
  if(jj > llimit) break;
  /* speed up comparison if use name length as first test */
  if(lpname[kk]==llnname && strcmp(ppname,nnod) == 0) {
    ppfound = pfound[kk];
    jj++;
    ntxt=ppfound.nText();
    *ff=0.;
    ierrf++;
    if (ntxt > 0 ){
      XMLCSTR txt = ppfound.getText(0);
      gg=0.;
      int ier =sscanf(txt,"%f",&gg);
      if(ier != 0 ) {
        ierrf--;
        *ff++=gg; 
        nval++;
      }
    }
  }
}  
return nval;
}


int rgetc_ (char *cf, int *limf, int *ncfield, int *nth, char *nname, int *cfstring, int lnname)
/* beware of MSVC call standard here (length follows string immediately)!!! */
/* returns nth instance into string field*/
{
char nodnam[60];
char *nnod;
XMLNode ppfound;
XMLCSTR ppname;
int kk;
int jj=0;
char *ccff;
int *limit;
int llimit;
int ntxt;
int seq = 0;
int nval =0;
int llnname;
int nnth;
XMLCSTR ttxt;
int infield = *ncfield;
nnth=*nth;
nnod=nname;
limit=limf;
llimit=*limf;
llnname=lnname;
ccff=cf;
/* name of node sought assume no trailing blanks */
for ( kk=0 ; kk < lnname ; kk++ ) nodnam[kk]= *nnod++ ;
nodnam[lnname] = 0;
nnod=nodnam;
for (kk=0 ; kk< nfound; kk++) {
  /*search list for matching name could optimise by several sort sorts */
  ppname = pname[kk];
  /* speed up comparison if use name length as first test 
  printf(" %d %d nm %s %s # %d %d\n",lpname[kk],llnname,ppname,nnod,infield,nfield);
  */
  if(lpname[kk]==llnname && strcmp(ppname,nnod) == 0 ) {
    seq++;
 /*   printf("match %d %d \n",nnth,seq);*/
   if(nnth == seq) {
     ppfound = pfound[kk];
     ntxt = ppfound.nText();
/*     printf(" ntxt  %d \n",ntxt);*/
     infield=0;
     XMLCSTR txt = ppfound.getText(infield);
     ttxt = txt;
     nval=0;

     while (*ttxt) {
        *ccff++=*ttxt++;
        nval++;
        if(nval == llimit) break;
        }
      break;
      }
/* set last character to 0 */      
    *ccff=0;
    }
  if(seq > nnth) break;
  }
return nval-1;
}


int rnodeinfo_(int *ntot, int *nsnod, int *natt, int *ntext,int *nth, char *nname, int lnname)
{
/* returns ntot    number of occurrences
           nsnod   number of subnodes
	   natt    number of attributes
	   ntext   number of text fields
   input   nth     results for nth occurrence (start at 1)
           nname   name of node length lnname (Given by
	   Fortran)*/   
char nodnam[60];
char *nnod;
XMLNode ppfound;
XMLCSTR ppname;
int kk;
int jj=0;
int nnth = *nth;
nnod=nname;
int llnname=lnname;
*nsnod = 0;
*natt = 0;
*ntext = 0;
/* name of node sought from Fortran to CSTR*/
for ( kk=0 ; kk < lnname ; kk++ ) nodnam[kk]= *nnod++ ;
nodnam[lnname] = 0;
nnod=nodnam;
/*printf(" nnod %s  given length %d /n",nnod,lnname);*/
/* how many instances are present ? (ntot) */
jj=0;
for (kk=0 ; kk < nfound ; kk++ ){
ppname = pname[kk];
/* speed up comparison if use name length as first test */
if(lpname[kk]==llnname && strcmp(ppname,nnod) == 0) {
jj++;
}
}
*ntot=jj;
/* return if not found or too great an instance*/
if (jj == 0 || nnth > jj  ) return jj-1;
jj=0;
for (kk=0 ; kk< nfound; kk++) {
ppname = pname[kk];
if(lpname[kk]==llnname && strcmp(ppname,nnod) == 0) {
ppfound = pfound[kk];
numnod = kk;
/* remember for attributes etc */
/*printf(" jj %d ",jj);*/
jj++;
}
if( jj == nnth ) break;
}
if(jj == 0 ) return jj-1;
/* get info from found node*/
nntext=ppfound.nText();
nnsnod=ppfound.nChildNode();
nnatt=ppfound.nAttribute();
*ntext = nntext;
*nsnod=nnsnod;
*natt = nnatt;
/* save location for reuse as start_branch or for attributes*/
numnth = nnth;
curset = 1;
curnod = ppfound;
return jj-1;
}

int curatts_(int *nth, char *attname, int *nlen, char *attval, int *nlev, int attnlen, int attvlen)
{
XMLCSTR txt;
char *tr;
int nuse;
int ii;
nuse = *nth;
if (curset == 0 ) return -1;
/* no info obtained and hence node not set; */
if ( numnth < nuse ) return -2;
/* asking for att greater than stored! */
txt = curnod.getAttributeName(numnth-1);
tr = attname;
ii =0;
while ( ii < attnlen ) {
  *tr++ = *txt;
  ii++;
  if ( *txt++ == 0 ) break;
  }
*nlen = ii-1;  
txt = curnod.getAttributeValue(numnth-1);
tr = attval;
ii =0;
while ( ii < attvlen ) {
  *tr++ = *txt;
  ii++;
  if ( *txt++ == 0 ) break;
  }
*nlev = ii-1;
return 0; 

}

}
