Open_xmlplo

g77,gfortran and gcc have been used to compile the
simple example plotting program xmlplo, a quick adaptation
from an ILL mulitplot SANS program.

xmplo_Win         using MinGW-g77 for windows
xmlplo_Oigf       using gfortran for Macintosh OSX-86
xmlplo_Linux      using g77 for Linux

FILENAMES

Treated data from SANS at the ILL have been identified by two numbers,
run and extension since 1974. This permits a wide range of 
experiments to be planned  and these identifiers can be scanned 
easily up or down e.g. during fitting sequences.  With about
60-80000 runs per year per instrument I usually propose that
the run number is reset to a small value each January. Raw
data are simply identified by the run number. Compressed
data have a .Z extension, and are compatible with most common
systems (zcat....)  Of course there are internal run numbers,
instrument identifiers etc., but the archive simply
has a  year+cycle_number/instrument_name/run_number as path name
(current cycle is data/, last is data-1/ )  It is easy to
search for breaks in sequence. 



Actual xml regrouped data filenames at the ILL are typically

xg001234_001.xml     i.e. xgnnnnnn_eee.xml
These are derived from the ILL ascii regrouped data files
g001234.001
(originally limited to match DOS 8.3 names)

Two-D ascii data have names tnnnnnn.eee


typically nnnnnn is the last run sequence number read in;
Usually a specific sample after all backgrounds and
detector calibrations have been read.

eee is a thre digit extension or version which is unique
and rolls around at 999.  Raw regrouped data usually start
with extension 0, though setting a new start, say 20
creates a clean sequence with updated files having an extension 21 
etc. If the file exists the extension is incremented to a unique
value.

qv ftp://ftp.ill.fr/pub/cs/sans/sans_manual.pdf

tag names
raw reduced intensities are I_counts
corrected are I_cm-1

As can be seen from this worked example details of the data file
structure are ignored!

Other useful components
Short-title  serves to identify curve (and sometimes includes
             a generated version number
One-step history
             This allows browsers to chain back through the
             histories in each component and build up a picture
             of treatment.

