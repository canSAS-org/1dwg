    Plotting SAS data from XML files

Batch file sasplo

This sets up the environment variables for the default
output devices of GRWND window graphics and PostScript
file hard copy.  PGPLOT_DIR points to the directory
containing GRWND.exe, PGPLOT_window.exe, grfont.dat
components necessary for PGPLOT window graphics.

Two example xml files are also located here.


The tag_directory file, in2ill.now, assigns tags to key numbers of
parameters in the ILL parameter and data lists.  The
file allows multipliers to be invoked on finding an
alias, eg nm-1 and A-1; the former is multiplied by 10

xmlplo allows an alternative directory file to be selected
simplifying mixing of data from different sources, though
alternative tag names can be incorporated in the default
file in2ill.now as shown.